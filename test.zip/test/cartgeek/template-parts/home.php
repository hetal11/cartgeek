 <?php /* Template Name: home */ ?>

<?php get_header(); ?>
<?php
   $sectionbanner =get_field('sectionbanner');
   if($sectionbanner):
?>
 <section class="sectionBanner" style="background: url(<?php echo $sectionbanner['background_img']['url']; ?>) no-repeat right -118px;background-size: 66%;">
         <div class="header py-3">
            <div class="container pl-0 pr-0">
               <nav class="navbar navbar-expand-lg navbar-light pl-0 pr-0">
                  <div class="brandLogo flex-shrink-1">
                     <img src="assets/images/logo.png" alt="" />
                     <?php 
                        the_custom_logo();

                     ?>
                  </div>
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                  </button> 
                 
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  
                     <?php
                      wp_nav_menu(
                     array(
                     'theme_location' => 'menu-1',
                     'menu_class'   =>'navbar-nav mr-auto ml-auto pl-0 pr-0',
                     'menu_id'        => 'primary-menu',
                   )
                );
         ?>
                     <form class="form-inline my-2 my-lg-0">
                        <button type="button" class="btn_Theme_green">GET IN TOUCH</button>
                     </form>
                  </div>
               </nav>
            </div>
         </div>
         <div class="banner">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-6">
                     <h1><?php echo $sectionbanner['heading1']; ?>
                        <?php echo $sectionbanner['heading2']; ?>
                     </h1>
                     <h6 class="mb-5"> <?php echo $sectionbanner['heading3']; ?></h6>
                     <button type="button" class="btn_Theme_green btnLg"> <?php echo $sectionbanner['link_text']; ?></button>
                  </div>
               </div>
            </div>
         </div>
      </section>
<?php
   $sectionGoodCompany =get_field('sectiongoodcompany');
   if($sectionGoodCompany):
?>
        <section class="sectionGoodCompany bg_Theme_green py-5">
         <div class="container">
            <div class="row">
               <div class="col">
                  <h3 class="text-white mb-4 text-center"><?php echo $sectionGoodCompany['title']; ?></h3>
                  <p class="text-white mb-5 text-center"><?php echo $sectionGoodCompany['description']; ?></p>
                  <div class="d-flex flex-wrap justify-content-center text-center text-white">
                     <div class="flex-fill points py-4 px-3 ml-0 mr-3">
                        <h4 class="my-4"><?php echo $sectionGoodCompany['flex-fill1']['number']; ?></h4>
                        <h5 class="mb-0"><?php echo $sectionGoodCompany['flex-fill1']['title']; ?></h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 mx-3">
                          <h4 class="my-4"><?php echo $sectionGoodCompany['flex-fill2']['number']; ?></h4>
                        <h5 class="mb-0"><?php echo $sectionGoodCompany['flex-fill2']['title']; ?></h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 mx-3">
                          <h4 class="my-4"><?php echo $sectionGoodCompany['flex-fill3']['number']; ?></h4>
                        <h5 class="mb-0"><?php echo $sectionGoodCompany['flex-fill3']['title']; ?></h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 mx-3">
                           <h4 class="my-4"><?php echo $sectionGoodCompany['flex-fill4']['number']; ?></h4>
                        <h5 class="mb-0"><?php echo $sectionGoodCompany['flex-fill4']['title']; ?></h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 ml-3 mr-0">
                         <h4 class="my-4"><?php echo $sectionGoodCompany['flex-fill5']['number']; ?></h4>
                        <h5 class="mb-0"><?php echo $sectionGoodCompany['flex-fill5']['title']; ?></h5>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   <?php endif; ?>
<?php
   $sectionecommerceplatform =get_field('sectionecommerceplatform');
   if($sectionecommerceplatform):
?>
      <section class="sectionEcommercePlatform py-5 overflow-hidden" style="background: url(<?php echo  $sectionecommerceplatform['background_image']['url']; ?>) no-repeat;position: right;">
         <div class="bg01"></div>
         <div class="container">
            <div class="col px-0">
               <div class="owl-carousel owl-theme" id="ecommerceCarousel">
                  <div class="item">
                     <div class="row no-gutters position-relative">
                        <div class="col-md-6 mb-md-0 p-md-4">
                           <h4 class="text-white"><?php echo $sectionecommerceplatform['owl-carousel1']['title'];  ?></h4>
                           <img src="<?php echo $sectionecommerceplatform['owl-carousel1']['image']['url'];  ?>" class="w-100" alt="" />
                        </div>
                        <div class="col-md-6 position-static ecommerce_cardbody p-5 pl-md-0">
                           <h2 class="mt-4 mb-5 text-white"><?php echo  $sectionecommerceplatform['owl-carousel1']['left_title'] ?></h2>
                           <p class="text-white pt-3 mb-5"><?php echo  $sectionecommerceplatform['owl-carousel1']['left_description'] ?></p>
                           <button type="button" class="btn_Theme_white text-dark mr-4"><?php echo  $sectionecommerceplatform['owl-carousel1']['button1'] ?></button>
                           <button type="button" class="btn_Transparent_green"><?php echo  $sectionecommerceplatform['owl-carousel1']['button2'] ?></button>
                        </div>
                     </div>
                  </div>
                   <div class="item">
                     <div class="row no-gutters position-relative">
                        <div class="col-md-6 mb-md-0 p-md-4">
                           <h4 class="text-white"><?php echo $sectionecommerceplatform['owl-carousel1']['title'];  ?></h4>
                           <img src="<?php echo $sectionecommerceplatform['owl-carousel1']['image']['url'];  ?>" class="w-100" alt="" />
                        </div>
                        <div class="col-md-6 position-static ecommerce_cardbody p-5 pl-md-0">
                           <h2 class="mt-4 mb-5 text-white"><?php echo  $sectionecommerceplatform['owl-carousel1']['left_title'] ?></h2>
                           <p class="text-white pt-3 mb-5"><?php echo  $sectionecommerceplatform['owl-carousel1']['left_description'] ?></p>
                           <button type="button" class="btn_Theme_white text-dark mr-4"><?php echo  $sectionecommerceplatform['owl-carousel1']['button1'] ?></button>
                           <button type="button" class="btn_Transparent_green"><?php echo  $sectionecommerceplatform['owl-carousel1']['button2'] ?></button>
                        </div>
                     </div>
                  </div>

                  <div class="item">
                     <div class="row no-gutters position-relative">
                        <div class="col-md-6 mb-md-0 p-md-4">
                           <h4 class="text-white"><?php echo $sectionecommerceplatform['owl-carousel1']['title'];  ?></h4>
                           <img src="<?php echo $sectionecommerceplatform['owl-carousel1']['image']['url'];  ?>" class="w-100" alt="" />
                        </div>
                        <div class="col-md-6 position-static ecommerce_cardbody p-5 pl-md-0">
                           <h2 class="mt-4 mb-5 text-white"><?php echo  $sectionecommerceplatform['owl-carousel1']['left_title'] ?></h2>
                           <p class="text-white pt-3 mb-5"><?php echo  $sectionecommerceplatform['owl-carousel1']['left_description'] ?></p>
                           <button type="button" class="btn_Theme_white text-dark mr-4"><?php echo  $sectionecommerceplatform['owl-carousel1']['button1'] ?></button>
                           <button type="button" class="btn_Transparent_green"><?php echo  $sectionecommerceplatform['owl-carousel1']['button2'] ?></button>
                        </div>
                     </div>
                  </div>

               </div>
            </div>
         </div>
      </section>
   <?php endif; ?>
      <div class="dottedDivbg py-5 w-100"></div>
      <?php
    
    $sectionelitecompany =get_field('sectionelitecompany');
    if($sectionelitecompany):
?>
      <section class="sectionEliteCompany bg_Theme_green py-5">
         <div class="container">
            <div class="d-flex">
               <div class="flex-fill text-white pr-3">
                  <h2 class="mb-5"><?php echo $sectionelitecompany['title']; ?> <br> <b><?php  echo $sectionelitecompany['title2'];?></b></h2>
                  <p class="mb-5"><?php  echo $sectionelitecompany['description'];?></p>
                  <button type="button" class="btn_Transparent_green btnLg"><?php  echo $sectionelitecompany['button'];?></button>
               </div>
               <div class="flex-fill pl-4">
                  <div class="d-flex flex-wrap">
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                     <div class="w-100 my-4"></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                     <div class="w-100 my-4"></div>
                    <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                     <div class="w-100 my-4"></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php echo $sectionelitecompany['flex-fill']['image']['url'];?>" alt="" /></span><?php echo $sectionelitecompany['flex-fill']['title'];?></div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   <?php endif; ?>
      <?php
   $sectionTechnology =get_field('sectiontechnology');
   if($sectionTechnology):
     
?>
      <section class="sectionTechnology py-5">
         <div class="container">
            <h3 class="text-dark mb-5 text-center"><b><?php echo $sectionTechnology['heading1']; ?></b><?php echo  ' ' .$sectionTechnology['sub_heading']; ?></h3>
            <div class="tabsWrap">
               <ul class="tabs-nav d-flex p-0">
                  <li class="active flex-fill text-center"><a href="#mobility"><?php  echo $sectionTechnology['tab_heading1']['heading']; ?></a></li>
                  <li class="flex-fill text-center"><a href="#web"><?php  echo $sectionTechnology['tab_heading2']['heading']; ?></a></li>
                  <li class="flex-fill text-center"><a href="#ecommerce"><?php  echo $sectionTechnology['tab_heading3']['heading']; ?></a></li>
                  <li class="flex-fill text-center"><a href="#designing"><?php  echo $sectionTechnology['tab_heading4']['heading']; ?></a></li>
               </ul>
               <div class="tabs-content">
                  <div class="tabsBody" id="mobility">
                     <div class="first_ring">
                        <div class="imgCenter center rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image1']['url']; ?>" class="p-3" alt="" /></div>
                     </div>
                     <div class="second_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image2']['url']; ?>" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image3']['url']; ?>" class="p-3" alt="" /></div>
                     </div>
                     <div class="third_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image1']['url']; ?>" class="p-3" alt="" /></div>
                        <div class="imgCenter center rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image2']['url']; ?>" class="p-4" alt="" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image3']['url']; ?>" class="p-4" alt="" /></div>
                     </div>
                  </div>
                  <div class="tabsBody" id="web" class="position-relative">
                     <div class="first_ring">
                        <div class="imgCenter center rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image1']['url']; ?>" class="p-3" alt="" /></div>
                     </div>
                     <div class="second_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image2']['url']; ?>" class="p-3" alt="" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image1']['url']; ?>" class="p-3" alt="" /></div>
                     </div>
                     <div class="third_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image1']['url']; ?>" class="p-3" alt="" /></div>
                        <div class="imgCenter center rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image1']['url']; ?>" class="p-4" alt="" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php echo $sectionTechnology['tab_heading1']['image1']['url']; ?>" class="p-4" alt="" /></div>
                     </div>
                  </div>
                  <div class="tabsBody" id="ecommerce">
                     <h3>Third Tab</h3>
                  </div>
                  <div class="tabsBody" id="designing">
                     <h3>Fourth Tab</h3>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <?php endif; ?>
         <?php
       $sectiontrusted =get_field('sectiontrusted');
   if($sectiontrusted):
     
?>
      <section class="sectionTrusted bg_Theme_darkcyan py-5">
         <div class="container">
            <div class="row">
               <div class="col">
                  <h3 class="text-white mb-4 text-center"><b><?php echo $sectiontrusted['title']; ?></b></h3>
                  <p class="text-white mb-5 text-center"><?php echo $sectiontrusted['description']; ?></p>
                  <div class="owl-carousel owl-theme trustedCarousel">
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3"><?php echo $sectiontrusted['owl-carousel1']['description'];?></p>
                              <h5 class="card-title"><?php echo $sectiontrusted['owl-carousel1']['title']; ?></h5>
                              <h6 class="card-subtitle mb-2 text-muted"><?php echo $sectiontrusted['owl-carousel1']['sub_title']; ?></h6>
                           </div>
                        </div>
                     </div>
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3"><?php echo $sectiontrusted['owl-carousel1']['description'];?></p>
                              <h5 class="card-title"><?php echo $sectiontrusted['owl-carousel1']['title']; ?></h5>
                              <h6 class="card-subtitle mb-2 text-muted"><?php echo $sectiontrusted['owl-carousel1']['sub_title']; ?></h6>
                           </div>
                        </div>
                     </div>
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3"><?php echo $sectiontrusted['owl-carousel1']['description'];?></p>
                              <h5 class="card-title"><?php echo $sectiontrusted['owl-carousel1']['title']; ?></h5>
                              <h6 class="card-subtitle mb-2 text-muted"><?php echo $sectiontrusted['owl-carousel1']['sub_title']; ?></h6>
                           </div>
                        </div>
                     </div>
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3"><?php echo $sectiontrusted['owl-carousel1']['description'];?></p>
                              <h5 class="card-title"><?php echo $sectiontrusted['owl-carousel1']['title']; ?></h5>
                              <h6 class="card-subtitle mb-2 text-muted"><?php echo $sectiontrusted['owl-carousel1']['sub_title']; ?></h6>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   <?php endif; ?>
        <?php
   $sectionTipsTrends =get_field('sectiontipstrends');
   if($sectionTipsTrends):
   
?>
      <section class="sectionTipsTrends py-5">
         <div class="container">
            <h3 class="text-dark mb-4 text-center"><b><?php echo $sectionTipsTrends['title'];?></b></h3>
            <div class="col">
               <div class="owl-carousel owl-theme tipsCarousel">
                  <div class="item">
                     <div class="card mb-3">
                        <div class="row no-gutters px-4">
                           <div class="col-md-4 py-4">
                              <img src="<?php echo $sectionTipsTrends['owl-carousel1']['image']['url']; ?>" class="card-img" alt="...">
                           </div>
                           <div class="col-md-8">
                              <div class="card-body pr-0">
                                 <h5 class="card-title"><?php echo $sectionTipsTrends['owl-carousel1']['title'];?></h5>
                                 <p class="card-text"><?php echo $sectionTipsTrends['owl-carousel1']['description'];?></p>
                                 <p class="card-text pt-3"><a href="javascript:void(0);" class="text-muted"><?php echo $sectionTipsTrends['owl-carousel1']['link_text']; ?></a></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                   <div class="item">
                     <div class="card mb-3">
                        <div class="row no-gutters px-4">
                           <div class="col-md-4 py-4">
                              <img src="<?php echo $sectionTipsTrends['owl-carousel1']['image']['url']; ?>" class="card-img" alt="...">
                           </div>
                           <div class="col-md-8">
                              <div class="card-body pr-0">
                                 <h5 class="card-title"><?php echo $sectionTipsTrends['owl-carousel1']['title'];?></h5>
                                 <p class="card-text"><?php echo $sectionTipsTrends['owl-carousel1']['description'];?></p>
                                 <p class="card-text pt-3"><a href="javascript:void(0);" class="text-muted"><?php echo $sectionTipsTrends['owl-carousel1']['link_text']; ?></a></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                   <div class="item">
                     <div class="card mb-3">
                        <div class="row no-gutters px-4">
                           <div class="col-md-4 py-4">
                              <img src="<?php echo $sectionTipsTrends['owl-carousel1']['image']['url']; ?>" class="card-img" alt="...">
                           </div>
                           <div class="col-md-8">
                              <div class="card-body pr-0">
                                 <h5 class="card-title"><?php echo $sectionTipsTrends['owl-carousel1']['title'];?></h5>
                                 <p class="card-text"><?php echo $sectionTipsTrends['owl-carousel1']['description'];?></p>
                                 <p class="card-text pt-3"><a href="javascript:void(0);" class="text-muted"><?php echo $sectionTipsTrends['owl-carousel1']['link_text']; ?></a></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   <?php endif; ?>
        <?php
   $sectionaboutgeek =get_field('sectionaboutgeek');
   if($sectionaboutgeek):
     
?>
      <section class="sectionAboutGeek bg_Theme_green pt-4 pb-5 text-white">
         <div class="container">
            <div class="row">
               <div class="col-6 pr-4">
                  <?php echo do_shortcode("[contact-form-7 id='252' title='We Hoped you'dend up here.']"); ?>
               </div>
               <div class="col-6">
                  <h3 class="text-white mb-3"><?php echo $sectionaboutgeek['title']; ?></h3>
                  <p class="mb-4"><?php echo $sectionaboutgeek['description']; ?></p>
                  <div class="imgCenter"><img src="<?php echo $sectionaboutgeek['image']['url'];?>" alt="" /></div>
               </div>
            </div>
         </div>
      </section>
   <?php endif; ?>
<?php endif; ?>
  <?php get_footer(); ?>    